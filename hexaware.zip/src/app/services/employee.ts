export interface Employee  {
	data:empdata[];
} 
interface empdata{id: number;
	first_name:string;
	last_name:string;
	email:string;
	avatar:string;}