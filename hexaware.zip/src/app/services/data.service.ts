import {Injectable} from '@angular/core';
import{Employee} from './employee'
import {HttpClient} from '@angular/common/http';


import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Injectable()

export class DataService {
    toggled:boolean=true;

	    constructor(private http:HttpClient){}
		// get ereturns observable response
getEmployee(): Observable<Employee>{
	//return this.http.get("https://reqres.in/api/users?page=2").map((res:any) => <Employee[]>res.json());
	//.map((response:Response)=> <Employee[]>response.json())
		//return this.http.get("https://reqres.in/api/users?page=2").map((res:any) => <Employee[]>res);
				return this.http.get<Employee>("https://reqres.in/api/users?page=2");


	
} 
saveDetails(requesOobject){
        return this.http.post('url', requesOobject);
    }
   
} 