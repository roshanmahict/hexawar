import { Component,OnInit } from '@angular/core';
import { DataService } from './services/data.service';
import{HeaderComponent} from '../app/component/header/header.component';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
	  constructor(private dataservice:DataService) { }

  title = 'hexaware';
  ngOnInit() {
	 
  }
   get data() {
		return this.dataservice.toggled;
	  }

	  set data(newData) {
		console.log("newData "+newData);
		this.dataservice.toggled = newData;
	  }
}
