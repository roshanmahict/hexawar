import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,ReactiveFormsModule, FormControl, NgForm,Validators} from '@angular/forms';
import { DataService } from '../../services/data.service';
@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css'],
    providers:[DataService]

})
export class UserprofileComponent implements OnInit {
	 demoForm:FormGroup;

	submitted = false;
  
  
  hideRequiredControl = new FormControl(false);
  floatLabelControl = new FormControl('auto');
fname:string="";
	lname:string="";
	  femail:string="";
	  fadd1:string="";
	  fadd2:string="";
	  fcity:string="";
  constructor(private _dataservice:DataService,private fb: FormBuilder) {
	 /* fname:new FormControl(), 
	  lname:new FormControl(),
	  femail:new FormControl(), 
	  fadd1:new FormControl(),
	  fadd2:new FormControl(), 
	  fcity:new FormControl()*/
	  
	   this.demoForm = this.fb.group({
      hideRequired: this.hideRequiredControl,
      floatLabel: this.floatLabelControl,
	  fname: [null, Validators.required],
		lname: [null, Validators.required],
		femail: [null, Validators.required],
		fadd1: [null, Validators.required],
		fadd2: [null, Validators.required],
		fcity: [null, Validators.required]
    })
  }
  //post 
postDataOnSubmit(form:NgForm){
		this.submitted = true;
		//post call here
		 console.log('you submitted value: ', form);
}
  ngOnInit() {
	  


  }
  

}
