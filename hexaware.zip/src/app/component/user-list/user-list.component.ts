import { Component, OnInit } from '@angular/core';
import{Employee} from '../../services/employee';
import { DataService } from '../../services/data.service';


@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css'],
  providers:[DataService]
})
export class UserListComponent implements OnInit {
employees:Employee;
  constructor(private _dataservice:DataService) { }

  ngOnInit() {
	 // this.employees = this._dataservice.getEmployee().subscribe((response) =>{
	 // response=JSON.stringify(Object.assign({}, response)))}
	// console.log(this._dataservice.getEmployee());
	 this._dataservice.getEmployee().subscribe(res => { console.log(res);
	 this.employees = res;
	 });
	 //console.log("employees"+this.employees);
  }

}
